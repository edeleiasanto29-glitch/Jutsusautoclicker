# Jutsu Auto Clicker 1.2

Automação experimental para o minigame de selos mostrado nas capturas do projeto.

## O que foi corrigido

- Removido o uso incompatível de `AccessibilityServiceInfo.FLAG_DEFAULT`.
- Coordenadas dos seis selos recalibradas para a tela de referência 1536x691.
- Recorte do OCR reduzido para a faixa onde aparece a sequência do Jutsu.
- Detector de sequência separado e testável, com correções conservadoras para erros comuns do OCR.
- Travamento contra cliques duplicados enquanto a mesma sequência continua visível, com rearmamento após a linha ficar limpa.
- Retries quando `dispatchGesture` é recusado/cancelado e gestos sem sobreposição entre os dedos.
- Painel flutuante arrastável, com pausa, ajuste de intervalo, atraso de lançamento e teste dos 6 selos.
- Interface principal refeita com fundo texturizado, cards e ícone de selo.
- Workflow do GitHub Actions com verificação prévia e build do APK debug.

## Fluxo de uso

1. Instale o APK.
2. Ative `Jutsu Auto Clicker` em Acessibilidade.
3. Permita sobreposição/painel flutuante.
4. Toque em `INICIAR AUTO JUTSU` e conceda a captura de tela.
5. No Roblox, posicione a bolha num canto livre.
6. Abra a bolha para testar Z/V/X/B/C/N e ajustar os tempos.

## Limites conhecidos

As coordenadas são normalizadas a partir da tela de referência. Como o Roblox pode reposicionar o teclado de selos conforme proporção, escala, barra de navegação e resolução do aparelho, pode ser necessário ajustar a calibração em outro dispositivo. O OCR também depende da qualidade/posição da interface na tela.
