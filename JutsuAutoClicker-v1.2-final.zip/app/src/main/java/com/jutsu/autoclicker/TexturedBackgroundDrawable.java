package com.jutsu.autoclicker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Fundo leve com textura geométrica, sem imagens externas. */
public class TexturedBackgroundDrawable extends Drawable {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pattern = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;

    public TexturedBackgroundDrawable(Context context) {
        density = context.getResources().getDisplayMetrics().density;
    }

    private float dp(float value) { return value * density; }

    @Override public void draw(Canvas canvas) {
        Rect b = getBounds();
        float w = b.width();
        float h = b.height();

        fill.setShader(new LinearGradient(0, 0, w, h,
                Color.rgb(8, 13, 27), Color.rgb(20, 16, 43), Shader.TileMode.CLAMP));
        canvas.drawRect(b, fill);

        pattern.setStyle(Paint.Style.STROKE);
        pattern.setStrokeWidth(dp(1));
        pattern.setColor(Color.argb(20, 255, 255, 255));
        float step = dp(44);
        for (float x = -h; x < w + h; x += step) {
            canvas.drawLine(x, 0, x + h, h, pattern);
        }

        pattern.setStyle(Paint.Style.FILL);
        pattern.setColor(Color.argb(18, 124, 103, 255));
        float dot = dp(2.2f);
        for (float y = dp(24); y < h; y += dp(58)) {
            for (float x = dp(18); x < w; x += dp(58)) {
                canvas.drawCircle(x + ((int)(y / dp(58)) % 2) * dp(12), y, dot, pattern);
            }
        }
    }

    @Override public void setAlpha(int alpha) { }
    @Override public void setColorFilter(android.graphics.ColorFilter colorFilter) { }
    @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
}
