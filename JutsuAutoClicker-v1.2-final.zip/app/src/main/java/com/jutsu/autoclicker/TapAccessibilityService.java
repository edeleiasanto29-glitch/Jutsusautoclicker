package com.jutsu.autoclicker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

/** Envia os toques pelos pontos calibrados do teclado de selos. */
public class TapAccessibilityService extends AccessibilityService {
    public static volatile TapAccessibilityService instance;

    private final Handler handler = new Handler(Looper.getMainLooper());

    // Calibrado pela captura de referência 1536x692: teclado de selos no canto superior direito.
    private static final float Z_X = 0.809f, Z_Y = 0.115f;
    private static final float V_X = 0.899f, V_Y = 0.115f;
    private static final float X_X = 0.808f, X_Y = 0.294f;
    private static final float B_X = 0.900f, B_Y = 0.294f;
    private static final float C_X = 0.809f, C_Y = 0.468f;
    private static final float N_X = 0.900f, N_Y = 0.468f;

    private static final int MAX_STROKES_PER_GESTURE = 6;
    private static final int MAX_RETRIES = 2;

    @Override public void onServiceConnected() {
        instance = this;
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
            info.notificationTimeout = 100;
            // Não usa FLAG_DEFAULT: a constante não existe em todas as APIs Android.
            setServiceInfo(info);
        }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        if (instance == this) instance = null;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    public boolean tapSequence(String sequence, int width, int height, long gapMs) {
        if (Build.VERSION.SDK_INT < 24 || sequence == null || sequence.isEmpty()) return false;
        if (width <= 0 || height <= 0 || AppSettings.isPaused(this)) return false;
        final String clean = sequence.toUpperCase().replaceAll("[^VBZXCN]", "");
        if (clean.length() < 2) return false;
        final long gap = Math.max(10, Math.min(120, gapMs));
        dispatchChunk(clean, 0, width, height, gap, 0);
        return true;
    }

    private void dispatchChunk(final String sequence, final int from, final int width,
                               final int height, final long gap, final int retry) {
        if (AppSettings.isPaused(this)) return;

        final int end = Math.min(sequence.length(), from + MAX_STROKES_PER_GESTURE);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        long start = 0;
        int valid = 0;

        for (int i = from; i < end; i++) {
            float[] p = point(sequence.charAt(i), width, height);
            if (p == null) continue;
            Path path = new Path();
            path.moveTo(p[0], p[1]);
            long duration = Math.max(1, Math.min(8, gap - 1));
            builder.addStroke(new GestureDescription.StrokeDescription(path, start, duration));
            start += gap;
            valid++;
        }

        if (valid == 0) return;
        final boolean more = end < sequence.length();
        final long launchDelay = AppSettings.getLaunchDelay(this);

        boolean accepted = dispatchGesture(builder.build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                if (AppSettings.isPaused(TapAccessibilityService.this)) return;
                if (more) {
                    handler.postDelayed(() -> dispatchChunk(sequence, end, width, height, gap, 0), 15);
                } else {
                    handler.postDelayed(() -> launch(width, height, 0), launchDelay);
                }
            }

            @Override public void onCancelled(GestureDescription gestureDescription) {
                if (!AppSettings.isPaused(TapAccessibilityService.this) && retry < MAX_RETRIES) {
                    handler.postDelayed(() -> dispatchChunk(sequence, from, width, height, gap, retry + 1), 70);
                }
            }
        }, handler);

        if (!accepted && retry < MAX_RETRIES) {
            handler.postDelayed(() -> dispatchChunk(sequence, from, width, height, gap, retry + 1), 70);
        }
    }

    private float[] point(char c, int width, int height) {
        switch (c) {
            case 'Z': return new float[]{Z_X * width, Z_Y * height};
            case 'V': return new float[]{V_X * width, V_Y * height};
            case 'X': return new float[]{X_X * width, X_Y * height};
            case 'B': return new float[]{B_X * width, B_Y * height};
            case 'C': return new float[]{C_X * width, C_Y * height};
            case 'N': return new float[]{N_X * width, N_Y * height};
            default: return null;
        }
    }

    public float[] getPointForTest(char key, int width, int height) {
        return point(Character.toUpperCase(key), width, height);
    }

    public void tapSingle(char key, int width, int height) {
        if (Build.VERSION.SDK_INT < 24 || AppSettings.isPaused(this)) return;
        float[] p = point(Character.toUpperCase(key), width, height);
        if (p == null) return;
        tapAt(p[0], p[1]);
    }

    public void tapLaunch(int width, int height) {
        if (Build.VERSION.SDK_INT < 24 || AppSettings.isPaused(this)) return;
        launch(width, height, 0);
    }

    private void tapAt(float x, float y) {
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(path, 0, 10));
        dispatchGesture(b.build(), null, handler);
    }

    /** Toca uma área realmente vazia abaixo do HUD do jogo para confirmar/lancar o jutsu. */
    private void launch(int width, int height, int retry) {
        if (AppSettings.isPaused(this)) return;
        float x = width * 0.50f;
        float y = height * 0.72f;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(path, 0, 10));
        boolean accepted = dispatchGesture(b.build(), null, handler);
        if (!accepted && retry < MAX_RETRIES) {
            handler.postDelayed(() -> launch(width, height, retry + 1), 70);
        }
    }
}
