package com.jutsu.autoclicker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;

/** Captura a tela, verifica a sequência do jutsu e controla o ciclo automático. */
public class CaptureService extends Service {
    public static volatile boolean running = false;
    public static volatile String detectedSequence = "";

    private static final String CHANNEL = "jutsu_auto";
    private static final int NOTIFICATION_ID = 9;

    // Recorte apertado sobre a linha "Coroa ... - VBZXZV" na interface do jogo.
    private static final float RX1 = 0.30f, RX2 = 0.70f, RY1 = 0.13f, RY2 = 0.285f;
    private static final long MIN_OCR_INTERVAL_MS = 85L;
    private static final long REARM_AFTER_EXECUTION_MS = 450L;

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private TextRecognizer recognizer;
    private Handler handler;
    private WindowManager windowManager;
    private LinearLayout overlayRoot;
    private TextView overlayStatus;
    private TextView overlaySequence;
    private TextView overlaySpeed;
    private TextView overlayLaunch;
    private Button bubble;
    private WindowManager.LayoutParams overlayParams;
    private boolean overlayExpanded = false;
    private boolean busy = false;
    private boolean armedForNextSequence = true;
    private String lastSequence = "";
    private long lastExecution = 0L;
    private long lastOcrStart = 0L;
    private long lastSequenceSeenAt = 0L;
    private int width;
    private int height;
    private MediaProjection.Callback projectionCallback;

    @Override public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        createChannel();
        try {
            promoteToForeground();
        } catch (Throwable t) {
            showStatus("Não foi possível iniciar o serviço");
            stopSelf();
            return START_NOT_STICKY;
        }

        if (intent == null) return START_NOT_STICKY;
        int result = intent.getIntExtra("resultCode", android.app.Activity.RESULT_CANCELED);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) {
            data = intent.getParcelableExtra("data", Intent.class);
        } else {
            //noinspection deprecation
            data = intent.getParcelableExtra("data");
        }

        if (result == android.app.Activity.RESULT_OK && data != null) {
            safeStartCapture(data);
        } else {
            showStatus("Captura não autorizada");
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void safeStartCapture(Intent data) {
        try {
            stopCaptureOnly();
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(android.app.Activity.RESULT_OK, data);
            if (projection == null) throw new IllegalStateException("MediaProjection nula");

            projectionCallback = new MediaProjection.Callback() {
                @Override public void onStop() {
                    handler.post(() -> {
                        stopCaptureOnly();
                        showStatus("Captura encerrada pelo sistema");
                        stopSelf();
                    });
                }
            };
            projection.registerCallback(projectionCallback, handler);

            width = getResources().getDisplayMetrics().widthPixels;
            height = getResources().getDisplayMetrics().heightPixels;
            if (width <= 0 || height <= 0) throw new IllegalStateException("Dimensão inválida");

            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            display = projection.createVirtualDisplay(
                    "JutsuOCR", width, height, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, handler);

            running = true;
            armedForNextSequence = true;
            lastSequence = "";
            lastExecution = 0L;
            detectedSequence = "";
            lastOcrStart = 0L;
            lastSequenceSeenAt = 0L;

            reader.setOnImageAvailableListener(r -> {
                Image image = null;
                try {
                    image = r.acquireLatestImage();
                    if (image == null) return;
                    if (AppSettings.isPaused(this) || busy) return;
                    long now = System.currentTimeMillis();
                    if (now - lastOcrStart < MIN_OCR_INTERVAL_MS) return;
                    lastOcrStart = now;
                    busy = true;
                    Bitmap full = imageToBitmap(image);
                    analyze(full);
                } catch (Throwable t) {
                    busy = false;
                    updateNotification("OCR/captura com erro — tentando novamente");
                } finally {
                    if (image != null) image.close();
                }
            }, handler);

            showOverlay();
            showStatus("RODANDO — verificando selos");
        } catch (Throwable t) {
            showStatus("Erro ao iniciar captura");
            stopCaptureOnly();
            stopSelf();
        }
    }

    private Bitmap imageToBitmap(Image image) {
        int iw = image.getWidth();
        int ih = image.getHeight();
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int rowPadding = Math.max(0, rowStride - pixelStride * iw);
        int paddedWidth = iw + (pixelStride == 0 ? 0 : rowPadding / pixelStride);

        Bitmap full = Bitmap.createBitmap(paddedWidth, ih, Bitmap.Config.ARGB_8888);
        buffer.rewind();
        full.copyPixelsFromBuffer(buffer);
        Bitmap out = Bitmap.createBitmap(full, 0, 0, iw, ih);
        full.recycle();
        width = iw;
        height = ih;
        return out;
    }

    private void analyze(Bitmap full) {
        int left = (int) (width * RX1);
        int top = (int) (height * RY1);
        int right = (int) (width * RX2);
        int bottom = (int) (height * RY2);
        if (right <= left || bottom <= top) {
            full.recycle();
            busy = false;
            return;
        }

        Bitmap crop = null;
        Bitmap scaled = null;
        try {
            crop = Bitmap.createBitmap(full, left, top, right - left, bottom - top);
            full.recycle();
            int sw = Math.max(1, crop.getWidth() * 2);
            int sh = Math.max(1, crop.getHeight() * 2);
            scaled = Bitmap.createScaledBitmap(crop, sw, sh, true);
            if (scaled != crop) crop.recycle();
            crop = null;

            final Bitmap input = scaled;
            pendingInput = input;
            recognizer.process(InputImage.fromBitmap(input, 0))
                    .addOnSuccessListener(text -> handleOcrResult(text))
                    .addOnFailureListener(e -> {
                        input.recycle();
                        busy = false;
                    });
        } catch (Throwable t) {
            if (crop != null && !crop.isRecycled()) crop.recycle();
            if (scaled != null && !scaled.isRecycled()) scaled.recycle();
            if (!full.isRecycled()) full.recycle();
            busy = false;
        }
    }

    private void handleOcrResult(Text text) {
        try {
            long now = System.currentTimeMillis();
            String sequence = findSequence(text);
            if (sequence == null || sequence.length() < 2) {
                // Só libera uma nova rodada depois de a linha ficar realmente
                // limpa por tempo suficiente. Isso evita duplicar um jutsu
                // quando o OCR falha em um frame isolado.
                if (!lastSequence.isEmpty() && now - lastSequenceSeenAt > 700) {
                    armedForNextSequence = true;
                    lastSequence = "";
                }
                detectedSequence = "";
                updateOverlaySequence("");
                return;
            }

            lastSequenceSeenAt = now;
            detectedSequence = sequence;
            updateOverlaySequence(sequence);

            long since = now - lastExecution;
            if (AppSettings.isPaused(this) || !armedForNextSequence || sequence.equals(lastSequence) || since < 160) return;

            TapAccessibilityService service = TapAccessibilityService.instance;
            if (service == null) {
                showStatus("Acessibilidade não conectada");
                return;
            }

            armedForNextSequence = false;
            lastSequence = sequence;
            lastExecution = System.currentTimeMillis();
            boolean sent = service.tapSequence(sequence, width, height, AppSettings.getGap(this));
            if (sent) {
                showStatus("SELOS: " + sequence);
                handler.postDelayed(() -> {
                    // Rearma mesmo se o jogo não limpou a linha rapidamente.
                    // A trava contra sequência igual permanece até o OCR detectar vazio.
                    if (lastSequence.equals(sequence) && System.currentTimeMillis() - lastExecution > REARM_AFTER_EXECUTION_MS) {
                        armedForNextSequence = true;
                    }
                }, REARM_AFTER_EXECUTION_MS);
            } else {
                armedForNextSequence = true;
                showStatus("Não foi possível enviar os selos");
            }
        } finally {
            if (text != null) { /* Text é gerenciado pelo ML Kit. */ }
            // O callback do ML Kit terminou de usar a Bitmap de entrada;
            // liberamos a cópia ampliada aqui para não acumular memória a cada frame.
            cleanupInput();
            busy = false;
        }
    }

    private Bitmap pendingInput;

    private void cleanupInput() {
        if (pendingInput != null && !pendingInput.isRecycled()) pendingInput.recycle();
        pendingInput = null;
    }

    private String findSequence(Text text) {
        String best = null;
        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String candidate = SealSequenceDetector.fromOcr(line.getText());
                if (candidate != null && (best == null || candidate.length() > best.length())) best = candidate;
            }
        }
        if (best == null) best = SealSequenceDetector.fromOcr(text.getText());
        return best;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Jutsu Auto Clicker", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Controle do leitor automático de jutsus");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void promoteToForeground() {
        Notification notification = notification("Preparando captura de tela");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        return builder.setContentTitle("Jutsu Auto Clicker")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void updateNotification(String text) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, notification(text));
    }

    private void showStatus(String text) {
        updateNotification(text);
        if (overlayStatus != null) handler.post(() -> {
            overlayStatus.setText(AppSettings.isPaused(this) ? "⏸ PAUSADO" : "● " + text);
            updateOverlayValues();
        });
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable bg(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), Color.argb(45, 255, 255, 255));
        return drawable;
    }

    private Button button(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(12);
        button.setAllCaps(false);
        button.setMinHeight(dp(40));
        button.setMinWidth(dp(46));
        button.setPadding(dp(6), 0, dp(6), 0);
        button.setBackground(bg(Color.argb(55, 124, 103, 255), 11));
        return button;
    }

    private TextView text(String value, float sizeSp) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(Color.WHITE);
        view.setTextSize(sizeSp);
        view.setGravity(Gravity.CENTER_VERTICAL);
        view.setPadding(dp(8), dp(3), dp(8), dp(3));
        return view;
    }

    private void showOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) return;
        if (overlayRoot != null) return;

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        overlayRoot = new LinearLayout(this);
        overlayRoot.setOrientation(LinearLayout.VERTICAL);
        overlayRoot.setPadding(dp(6), dp(6), dp(6), dp(6));
        overlayRoot.setBackground(new TexturedBackgroundDrawable(this));

        bubble = button(AppSettings.isPaused(this) ? "▶" : "Ⅱ");
        bubble.setTextSize(18);
        overlayRoot.addView(bubble, new LinearLayout.LayoutParams(dp(54), dp(50)));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setVisibility(overlayExpanded ? LinearLayout.VISIBLE : LinearLayout.GONE);
        panel.setPadding(dp(3), dp(4), dp(3), 0);

        overlayStatus = text("● ATIVO", 12);
        panel.addView(overlayStatus, new LinearLayout.LayoutParams(dp(220), dp(31)));
        overlaySequence = text("Aguardando selos...", 13);
        overlaySequence.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        panel.addView(overlaySequence, new LinearLayout.LayoutParams(dp(220), dp(38)));

        LinearLayout gapRow = row("Intervalo");
        overlaySpeed = text("", 12);
        Button gapMinus = button("−");
        Button gapPlus = button("+");
        gapMinus.setOnClickListener(v -> { AppSettings.setGap(this, AppSettings.getGap(this) - 1); updateOverlayValues(); });
        gapPlus.setOnClickListener(v -> { AppSettings.setGap(this, AppSettings.getGap(this) + 1); updateOverlayValues(); });
        gapRow.addView(gapMinus);
        gapRow.addView(overlaySpeed, new LinearLayout.LayoutParams(0, dp(40), 1));
        gapRow.addView(gapPlus);
        panel.addView(gapRow);

        LinearLayout launchRow = row("Lançar");
        overlayLaunch = text("", 12);
        Button launchMinus = button("−");
        Button launchPlus = button("+");
        launchMinus.setOnClickListener(v -> { AppSettings.setLaunchDelay(this, AppSettings.getLaunchDelay(this) - 10); updateOverlayValues(); });
        launchPlus.setOnClickListener(v -> { AppSettings.setLaunchDelay(this, AppSettings.getLaunchDelay(this) + 10); updateOverlayValues(); });
        launchRow.addView(launchMinus);
        launchRow.addView(overlayLaunch, new LinearLayout.LayoutParams(0, dp(40), 1));
        launchRow.addView(launchPlus);
        panel.addView(launchRow);

        TextView testsLabel = text("Testar toques", 11);
        panel.addView(testsLabel, new LinearLayout.LayoutParams(dp(220), dp(29)));
        LinearLayout r1 = new LinearLayout(this);
        LinearLayout r2 = new LinearLayout(this);
        LinearLayout r3 = new LinearLayout(this);
        for (LinearLayout row : new LinearLayout[]{r1, r2, r3}) row.setOrientation(LinearLayout.HORIZONTAL);
        addTestKey(r1, 'Z'); addTestKey(r1, 'V');
        addTestKey(r2, 'X'); addTestKey(r2, 'B');
        addTestKey(r3, 'C'); addTestKey(r3, 'N');
        panel.addView(r1); panel.addView(r2); panel.addView(r3);

        Button launchTest = button("Testar lançamento");
        launchTest.setOnClickListener(v -> {
            TapAccessibilityService service = TapAccessibilityService.instance;
            if (service != null) service.tapLaunch(width, height);
        });
        panel.addView(launchTest, new LinearLayout.LayoutParams(dp(220), dp(42)));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button pause = button("Pausar");
        Button stop = button("Parar");
        pause.setOnClickListener(v -> togglePause());
        stop.setOnClickListener(v -> stopSelf());
        actions.addView(pause, new LinearLayout.LayoutParams(0, dp(42), 1));
        actions.addView(stop, new LinearLayout.LayoutParams(0, dp(42), 1));
        panel.addView(actions);

        overlayRoot.addView(panel);

        bubble.setOnTouchListener(new ViewDragTouchListener());

        overlayParams = new WindowManager.LayoutParams(
                dp(235), WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.BOTTOM | Gravity.LEFT;
        overlayParams.x = dp(12);
        overlayParams.y = dp(28);

        try {
            windowManager.addView(overlayRoot, overlayParams);
            updateOverlayValues();
        } catch (Throwable ignored) {
            overlayRoot = null;
        }
    }

    private class ViewDragTouchListener implements android.view.View.OnTouchListener {
        private float downRawX, downRawY;
        private int startX, startY;
        private boolean moved;

        @Override public boolean onTouch(android.view.View v, MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX = event.getRawX();
                    downRawY = event.getRawY();
                    startX = overlayParams.x;
                    startY = overlayParams.y;
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - downRawX;
                    float dy = event.getRawY() - downRawY;
                    if (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) moved = true;
                    if (moved && windowManager != null && overlayRoot != null) {
                        overlayParams.x = Math.max(0, startX + (int) dx);
                        overlayParams.y = Math.max(0, startY - (int) dy);
                        try { windowManager.updateViewLayout(overlayRoot, overlayParams); } catch (Throwable ignored) { }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved) toggleOverlayExpanded();
                    return true;
                default:
                    return true;
            }
        }
    }

    private void toggleOverlayExpanded() {
        overlayExpanded = !overlayExpanded;
        LinearLayout panel = (LinearLayout) overlayRoot.getChildAt(1);
        panel.setVisibility(overlayExpanded ? LinearLayout.VISIBLE : LinearLayout.GONE);
        bubble.setText(overlayExpanded ? "×" : (AppSettings.isPaused(this) ? "▶" : "Ⅱ"));
        updateOverlaySize();
    }

    private void addTestKey(LinearLayout row, final char key) {
        Button b = button(String.valueOf(key));
        b.setOnClickListener(v -> {
            TapAccessibilityService service = TapAccessibilityService.instance;
            if (service != null) service.tapSingle(key, width, height);
        });
        row.addView(b, new LinearLayout.LayoutParams(0, dp(39), 1));
    }

    private LinearLayout row(String title) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView label = text(title, 11);
        row.addView(label, new LinearLayout.LayoutParams(dp(70), dp(40)));
        return row;
    }

    private void updateOverlaySize() {
        if (windowManager != null && overlayRoot != null && overlayParams != null) {
            try { windowManager.updateViewLayout(overlayRoot, overlayParams); } catch (Throwable ignored) { }
        }
    }

    private void updateOverlayValues() {
        if (overlaySpeed != null) overlaySpeed.setText(AppSettings.getGap(this) + " ms");
        if (overlayLaunch != null) overlayLaunch.setText(AppSettings.getLaunchDelay(this) + " ms");
    }

    private void updateOverlaySequence(String sequence) {
        if (overlaySequence == null) return;
        handler.post(() -> overlaySequence.setText(sequence == null || sequence.isEmpty()
                ? "Aguardando selos..." : "Selos: " + sequence));
    }

    private void togglePause() {
        boolean paused = !AppSettings.isPaused(this);
        AppSettings.setPaused(this, paused);
        if (!paused) {
            armedForNextSequence = true;
            lastSequence = "";
        }
        if (bubble != null && !overlayExpanded) bubble.setText(paused ? "▶" : "Ⅱ");
        showStatus(paused ? "Pausado" : "Rodando");
    }

    private void removeOverlay() {
        if (windowManager != null && overlayRoot != null) {
            try { windowManager.removeView(overlayRoot); } catch (Throwable ignored) { }
        }
        overlayRoot = null;
        overlayStatus = null;
        overlaySequence = null;
        overlaySpeed = null;
        overlayLaunch = null;
        bubble = null;
    }

    private void stopCaptureOnly() {
        running = false;
        detectedSequence = "";
        if (reader != null) {
            try { reader.setOnImageAvailableListener(null, null); } catch (Throwable ignored) { }
            try { reader.close(); } catch (Throwable ignored) { }
            reader = null;
        }
        if (display != null) {
            try { display.release(); } catch (Throwable ignored) { }
            display = null;
        }
        if (projection != null) {
            try { if (projectionCallback != null) projection.unregisterCallback(projectionCallback); } catch (Throwable ignored) { }
            try { projection.stop(); } catch (Throwable ignored) { }
            projection = null;
            projectionCallback = null;
        }
        busy = false;
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        stopCaptureOnly();
        cleanupInput();
        removeOverlay();
        if (recognizer != null) {
            try { recognizer.close(); } catch (Throwable ignored) { }
            recognizer = null;
        }
        try {
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.cancel(NOTIFICATION_ID);
        } catch (Throwable ignored) { }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
