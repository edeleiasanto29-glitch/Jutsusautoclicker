package com.jutsu.autoclicker;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Detector puro de sequências dos seis selos: V, B, Z, X, C e N.
 * Mantém o OCR separado da lógica de validação para facilitar testes.
 */
public final class SealSequenceDetector {
    private static final Pattern STRICT = Pattern.compile("[VBZXCN]{2,12}");
    private static final Pattern FUZZY = Pattern.compile("[VBZXCN]{4,12}");

    private SealSequenceDetector() {}

    public static String fromOcr(String raw) {
        if (raw == null || raw.isEmpty()) return null;

        String compact = compact(raw);
        String strict = longestMatch(compact, STRICT);

        // Correções conservadoras para erros comuns de OCR. Evitamos O/G -> C
        // porque isso cria muitos falsos positivos em palavras normais.
        String fuzzyInput = compact
                .replace('8', 'B')
                .replace('2', 'Z')
                .replace('Y', 'V')
                .replace('K', 'X')
                .replace('H', 'N')
                .replace('P', 'B');
        String fuzzy = longestMatch(fuzzyInput, FUZZY);

        // Só aceitamos a correção fuzzy quando ela realmente recupera uma
        // sequência maior que a leitura estrita; assim evitamos falsos positivos.
        if (fuzzy != null && (strict == null || fuzzy.length() > strict.length())) return fuzzy;
        return strict;
    }

    static String compact(String raw) {
        return raw.toUpperCase(Locale.US).replaceAll("[^A-Z0-9]", "");
    }

    static String longestMatch(String text, Pattern pattern) {
        String best = null;
        int bestStart = -1;
        Matcher m = pattern.matcher(text);
        while (m.find()) {
            String value = m.group();
            // Em empate, prefere a ocorrência mais à direita: no HUD do jogo
            // a sequência aparece depois do nome do jutsu.
            if (best == null || value.length() > best.length()
                    || (value.length() == best.length() && m.start() > bestStart)) {
                best = value;
                bestStart = m.start();
            }
        }
        return best;
    }
}
