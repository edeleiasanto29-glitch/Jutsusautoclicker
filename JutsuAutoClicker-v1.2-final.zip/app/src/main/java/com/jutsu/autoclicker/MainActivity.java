package com.jutsu.autoclicker;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 4001;
    private static final int REQ_NOTIFICATIONS = 4002;

    private TextView status;
    private TextView accessStatus;
    private TextView overlayStatus;
    private TextView captureStatus;
    private TextView speedValue;
    private TextView launchValue;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            updateChecks();
            if (isFinishing()) return;
            uiHandler.postDelayed(this, 900);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        uiHandler.removeCallbacks(refresh);
        uiHandler.post(refresh);
    }

    @Override protected void onDestroy() {
        uiHandler.removeCallbacks(refresh);
        super.onDestroy();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView tv(String value, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private GradientDrawableCompat cardBackground(int color, int radius) {
        return new GradientDrawableCompat(color, dp(radius));
    }

    private static class GradientDrawableCompat extends android.graphics.drawable.GradientDrawable {
        GradientDrawableCompat(int color, int radiusPx) {
            setColor(color);
            setCornerRadius(radiusPx);
            setStroke(radiusPx > 0 ? Math.max(1, radiusPx / 24) : 1, Color.argb(38, 255, 255, 255));
        }
    }

    private Button actionButton(String title, boolean primary) {
        Button b = new Button(this);
        b.setText(title);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setMinHeight(dp(48));
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setBackground(cardBackground(primary ? Color.rgb(95, 76, 210) : Color.argb(58, 255, 255, 255), 13));
        return b;
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackground(new TexturedBackgroundDrawable(this));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(24), dp(18), dp(28));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(15), dp(14), dp(15), dp(14));
        header.setBackground(cardBackground(Color.argb(82, 20, 24, 48), 20));

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_seal_mark);
        icon.setPadding(dp(9), dp(9), dp(9), dp(9));
        icon.setBackground(cardBackground(Color.rgb(92, 73, 205), 15));
        header.addView(icon, new LinearLayout.LayoutParams(dp(54), dp(54)));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(12), 0, 0, 0);
        TextView title = tv("Jutsu Auto Clicker", 23, Color.WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        titleBox.addView(title);
        TextView subtitle = tv("Leitor de selos • Roblox", 13, Color.argb(185, 235, 235, 255));
        titleBox.addView(subtitle);
        header.addView(titleBox, new LinearLayout.LayoutParams(0, dp(58), 1));
        content.addView(header);

        TextView hint = tv("Leia a sequência no topo, toque os selos na ordem e lance o jutsu automaticamente.", 14, Color.argb(220, 245, 245, 255));
        hint.setPadding(dp(4), dp(14), dp(4), dp(14));
        content.addView(hint);

        LinearLayout statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.VERTICAL);
        statusCard.setPadding(dp(15), dp(12), dp(15), dp(12));
        statusCard.setBackground(cardBackground(Color.argb(75, 14, 18, 38), 17));

        TextView statusTitle = tv("STATUS", 11, Color.argb(170, 220, 220, 255));
        statusTitle.setTypeface(Typeface.DEFAULT_BOLD);
        statusCard.addView(statusTitle);
        status = tv("Preparando...", 15, Color.WHITE);
        status.setTypeface(Typeface.DEFAULT_BOLD);
        status.setPadding(0, dp(5), 0, dp(3));
        statusCard.addView(status);
        content.addView(statusCard);

        TextView checksTitle = tv("Permissões e captura", 16, Color.WHITE);
        checksTitle.setTypeface(Typeface.DEFAULT_BOLD);
        checksTitle.setPadding(dp(4), dp(18), dp(4), dp(8));
        content.addView(checksTitle);

        accessStatus = addCheckCard(content, "Acessibilidade", "Permite enviar os toques dos selos");
        overlayStatus = addCheckCard(content, "Painel flutuante", "Mantém os controles por cima do Roblox");
        captureStatus = addCheckCard(content, "Captura de tela", "Lê a sequência com o OCR");

        Button access = actionButton("Abrir Acessibilidade", false);
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        content.addView(access, marginParams(0, 7, 0, 0));

        Button overlay = actionButton("Permitir painel flutuante", false);
        overlay.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())));
                } catch (Throwable t) {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
                }
            }
        });
        content.addView(overlay, marginParams(0, 7, 0, 0));

        TextView settingsTitle = tv("Velocidade", 16, Color.WHITE);
        settingsTitle.setTypeface(Typeface.DEFAULT_BOLD);
        settingsTitle.setPadding(dp(4), dp(19), dp(4), dp(4));
        content.addView(settingsTitle);

        LinearLayout speedCard = new LinearLayout(this);
        speedCard.setOrientation(LinearLayout.VERTICAL);
        speedCard.setPadding(dp(14), dp(10), dp(14), dp(10));
        speedCard.setBackground(cardBackground(Color.argb(65, 20, 24, 48), 16));
        speedValue = tv("", 13, Color.WHITE);
        speedValue.setTypeface(Typeface.DEFAULT_BOLD);
        speedCard.addView(speedValue);
        SeekBar speed = new SeekBar(this);
        speed.setMax(110);
        speed.setProgress(clamp(AppSettings.getGap(this) - 10, 0, 110));
        speed.setProgressTintList(ColorStateList.valueOf(Color.rgb(118, 98, 240)));
        speed.setThumbTintList(ColorStateList.valueOf(Color.WHITE));
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                AppSettings.setGap(MainActivity.this, 10 + progress);
                updateValues();
            }
            public void onStartTrackingTouch(SeekBar bar) { }
            public void onStopTrackingTouch(SeekBar bar) { }
        });
        speedCard.addView(speed);
        launchValue = tv("", 12, Color.argb(195, 230, 230, 255));
        speedCard.addView(launchValue);
        content.addView(speedCard);

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        Button start = actionButton("▶  INICIAR AUTO JUTSU", true);
        start.setOnClickListener(v -> requestCapture());
        Button stop = actionButton("■  PARAR", false);
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, CaptureService.class));
            updateStatusText("PARADO");
        });
        actionRow.addView(start, new LinearLayout.LayoutParams(0, dp(52), 1));
        LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(0, dp(52), 0.53f);
        stopParams.leftMargin = dp(8);
        actionRow.addView(stop, stopParams);
        content.addView(actionRow, marginParams(0, 16, 0, 0));

        TextView footer = tv("Dica: depois de iniciar, arraste a bolha para um canto livre. Abra a bolha para ajustar o intervalo, testar cada selo e pausar.", 12, Color.argb(180, 235, 235, 255));
        footer.setPadding(dp(4), dp(14), dp(4), 0);
        content.addView(footer);

        scroll.addView(content);
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        updateValues();
        updateChecks();
    }

    private TextView addCheckCard(LinearLayout parent, String title, String detail) {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(13), dp(9), dp(13), dp(9));
        card.setBackground(cardBackground(Color.argb(55, 255, 255, 255), 14));

        TextView dot = tv("●", 18, Color.rgb(240, 168, 75));
        dot.setGravity(Gravity.CENTER);
        card.addView(dot, new LinearLayout.LayoutParams(dp(32), dp(40)));

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        TextView t = tv(title, 13, Color.WHITE);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        TextView d = tv(detail, 11, Color.argb(175, 235, 235, 255));
        copy.addView(t);
        copy.addView(d);
        card.addView(copy, new LinearLayout.LayoutParams(0, dp(42), 1));

        TextView state = tv("—", 11, Color.WHITE);
        state.setGravity(Gravity.CENTER);
        card.addView(state, new LinearLayout.LayoutParams(dp(66), dp(38)));

        parent.addView(card, marginParams(0, 5, 0, 0));
        return state;
    }

    private LinearLayout.LayoutParams marginParams(int l, int top, int r, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.leftMargin = dp(l);
        p.topMargin = dp(top);
        p.rightMargin = dp(r);
        p.bottomMargin = dp(bottom);
        return p;
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private boolean hasAccessibility() {
        return TapAccessibilityService.instance != null;
    }

    private boolean hasOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private void updateChecks() {
        boolean a = hasAccessibility();
        boolean o = hasOverlay();
        boolean c = CaptureService.running;
        setCheck(accessStatus, a);
        setCheck(overlayStatus, o);
        setCheck(captureStatus, c);
        if (status != null) {
            if (c) updateStatusText(CaptureService.detectedSequence.isEmpty()
                    ? "RODANDO • procurando a sequência..."
                    : "RODANDO • selo detectado: " + CaptureService.detectedSequence);
            else if (!a) updateStatusText("Aguardando Acessibilidade");
            else if (!o) updateStatusText("Aguardando permissão de painel");
            else updateStatusText("Pronto para iniciar");
        }
        updateValues();
    }

    private void setCheck(TextView state, boolean ok) {
        if (state == null) return;
        state.setText(ok ? "ATIVO" : "PENDENTE");
        state.setTextColor(ok ? Color.rgb(108, 220, 150) : Color.rgb(255, 194, 103));
    }

    private void updateValues() {
        if (speedValue != null) speedValue.setText("Intervalo entre selos: " + AppSettings.getGap(this) + " ms");
        if (launchValue != null) launchValue.setText("Atraso antes do lançamento: " + AppSettings.getLaunchDelay(this) + " ms • ajuste também no painel");
    }

    private void updateStatusText(String value) {
        if (status != null) status.setText(value);
    }

    private void requestCapture() {
        if (!hasAccessibility()) {
            Toast.makeText(this, "Ative o serviço em Acessibilidade primeiro.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        if (!hasOverlay()) {
            Toast.makeText(this, "Permita o painel flutuante primeiro.", Toast.LENGTH_LONG).show();
            return;
        }
        AppSettings.setPaused(this, false);
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (manager == null) {
            Toast.makeText(this, "MediaProjection não disponível neste aparelho.", Toast.LENGTH_LONG).show();
            return;
        }
        startActivityForResult(manager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            updateStatusText("Captura cancelada");
            return;
        }
        Intent service = new Intent(this, CaptureService.class);
        service.putExtra("resultCode", resultCode);
        service.putExtra("data", data);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
            else startService(service);
            updateStatusText("INICIANDO • aguardando OCR...");
        } catch (Throwable t) {
            Toast.makeText(this, "Não foi possível iniciar a captura.", Toast.LENGTH_LONG).show();
            updateStatusText("Falha ao iniciar captura");
        }
    }
}
