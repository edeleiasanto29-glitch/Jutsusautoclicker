package com.jutsu.autoclicker;

import android.content.Context;
import android.content.SharedPreferences;

/** Centraliza as configurações compartilhadas entre Activity, OCR e acessibilidade. */
public final class AppSettings {
    private static final String PREFS = "jutsu_settings";
    private static final String KEY_GAP = "gap_ms";
    private static final String KEY_LAUNCH = "launch_delay_ms";
    private static final String KEY_PAUSED = "paused";

    public static final int DEFAULT_GAP = 16;
    public static final int DEFAULT_LAUNCH_DELAY = 90;

    private AppSettings() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static int getGap(Context c) {
        return p(c).getInt(KEY_GAP, DEFAULT_GAP);
    }

    public static void setGap(Context c, int value) {
        p(c).edit().putInt(KEY_GAP, clamp(value, 10, 120)).apply();
    }

    public static int getLaunchDelay(Context c) {
        return p(c).getInt(KEY_LAUNCH, DEFAULT_LAUNCH_DELAY);
    }

    public static void setLaunchDelay(Context c, int value) {
        p(c).edit().putInt(KEY_LAUNCH, clamp(value, 20, 1000)).apply();
    }

    public static boolean isPaused(Context c) {
        return p(c).getBoolean(KEY_PAUSED, false);
    }

    public static void setPaused(Context c, boolean paused) {
        p(c).edit().putBoolean(KEY_PAUSED, paused).apply();
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}
