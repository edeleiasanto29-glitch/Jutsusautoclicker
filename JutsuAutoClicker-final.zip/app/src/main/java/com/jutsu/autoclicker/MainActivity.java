package com.jutsu.autoclicker;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 4001;
    private static final int REQ_NOTIFICATIONS = 4002;
    private TextView status, speed, launchDelay;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            buildUi();
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
            }
        } catch (Throwable t) {
            Toast.makeText(this, "Falha ao abrir o app. Tente reinstalar a versão nova.", Toast.LENGTH_LONG).show();
        }
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20),dp(20),dp(20),dp(20));

        TextView title = new TextView(this);
        title.setText("Jutsu Auto Clicker"); title.setTextSize(26); title.setPadding(0,0,0,dp(10));
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("1) Ative Acessibilidade  2) Permita sobreposição  3) Inicie a captura. Depois use o mini painel flutuante para pausar e ajustar a velocidade.");
        info.setTextSize(15); root.addView(info);

        status = new TextView(this); status.setTextSize(15); status.setPadding(0,dp(18),0,dp(14)); root.addView(status);

        Button access = new Button(this);
        access.setText("1. Ativar Acessibilidade");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access);

        Button overlay = new Button(this);
        overlay.setText("2. Permitir painel flutuante");
        overlay.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23)
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));
        });
        root.addView(overlay);

        speed = new TextView(this); speed.setPadding(0,dp(14),0,dp(4)); root.addView(speed);
        SeekBar bar = new SeekBar(this);
        bar.setMax(115);
        bar.setProgress(Math.max(0, Math.min(115, AppSettings.getGap(this)-5)));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean f){
                AppSettings.setGap(MainActivity.this, 5+p); updateValues();
            }
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){}
        });
        root.addView(bar);

        launchDelay = new TextView(this); launchDelay.setPadding(0,dp(10),0,dp(4)); root.addView(launchDelay);

        Button start = new Button(this);
        start.setText("3. INICIAR AUTO JUTSU");
        start.setOnClickListener(v -> requestCapture()); root.addView(start);

        Button stop = new Button(this);
        stop.setText("PARAR");
        stop.setOnClickListener(v -> { stopService(new Intent(this, CaptureService.class)); updateStatus("PARADO"); });
        root.addView(stop);

        setContentView(root); updateValues(); updateStatus(null);
    }

    private void updateValues() {
        if (speed != null) speed.setText("Intervalo entre selos: " + AppSettings.getGap(this) + " ms");
        if (launchDelay != null) launchDelay.setText("Atraso para lançar: " + AppSettings.getLaunchDelay(this) + " ms (ajuste no painel flutuante)");
    }

    private void updateStatus(String forced) {
        if (status == null) return;
        if (forced != null) {
            status.setText("Status: " + forced);
            return;
        }
        boolean a = TapAccessibilityService.instance != null;
        status.setText("Acessibilidade: " + (a ? "ATIVA" : "não conectada")
                + "\nIntervalo: " + AppSettings.getGap(this) + " ms");
    }

    private void requestCapture() {
        if (TapAccessibilityService.instance == null) {
            Toast.makeText(this,"Primeiro ative o serviço em Acessibilidade.",Toast.LENGTH_LONG).show(); return;
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this,"Ative a permissão do painel flutuante.",Toast.LENGTH_LONG).show();
            return;
        }
        AppSettings.setPaused(this, false);
        MediaProjectionManager m=(MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_CAPTURE && resultCode==RESULT_OK && data!=null){
            Intent i=new Intent(this,CaptureService.class);
            i.putExtra("resultCode",resultCode); i.putExtra("data",data);
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            status.setText("Status: RODANDO — painel flutuante ativo");
        }
    }
}
