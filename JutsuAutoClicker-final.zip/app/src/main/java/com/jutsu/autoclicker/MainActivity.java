package com.jutsu.autoclicker;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 4001;
    private TextView status, speed;
    private int gap = 12;

    @Override public void onCreate(Bundle b) { super.onCreate(b); buildUi(); }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36,36,36,36);

        TextView title = new TextView(this);
        title.setText("Jutsu Auto Clicker"); title.setTextSize(28); title.setPadding(0,0,0,18);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Lê automaticamente a sequência de selos que aparece no topo, toca Z/V/X/B/C/N na mesma ordem e depois toca uma área vazia para lançar o jutsu. O ciclo continua para os próximos jutsus.");
        info.setTextSize(16); root.addView(info);

        status = new TextView(this); status.setText("Status: preparando..."); status.setPadding(0,20,0,20); root.addView(status);

        Button access = new Button(this);
        access.setText("1. Ativar permissão de toques");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access);

        Button overlay = new Button(this);
        overlay.setText("2. Permitir sobreposição (opcional)");
        overlay.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23)
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));
        });
        root.addView(overlay);

        speed = new TextView(this);
        speed.setText("Intervalo entre selos: " + gap + " ms"); speed.setPadding(0,18,0,4); root.addView(speed);
        SeekBar bar = new SeekBar(this);
        bar.setMax(29); bar.setProgress(23);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean f){
                gap=6+(29-p); speed.setText("Intervalo entre selos: "+gap+" ms");
            }
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){}
        });
        root.addView(bar);

        Button start = new Button(this);
        start.setText("3. INICIAR LEITOR + AUTO JUTSU");
        start.setOnClickListener(v -> requestCapture()); root.addView(start);

        Button stop = new Button(this);
        stop.setText("PARAR");
        stop.setOnClickListener(v -> { stopService(new Intent(this, CaptureService.class)); status.setText("Status: PARADO"); });
        root.addView(stop);

        setContentView(root); updateStatus();
    }

    private void updateStatus() {
        boolean a = TapAccessibilityService.instance != null;
        status.setText("Toque automático: " + (a ? "ATIVO" : "não conectado") + "\nIntervalo: " + gap + " ms\nLeitor: área superior central");
    }

    private void requestCapture() {
        if (TapAccessibilityService.instance == null) {
            Toast.makeText(this,"Ative o serviço de acessibilidade primeiro.",Toast.LENGTH_LONG).show(); return;
        }
        MediaProjectionManager m=(MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_CAPTURE && resultCode==RESULT_OK && data!=null){
            Intent i=new Intent(this,CaptureService.class);
            i.putExtra("resultCode",resultCode); i.putExtra("data",data); i.putExtra("gap",gap);
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            status.setText("Status: RODANDO — aguardando próximo jutsu");
        }
    }
}
