package com.jutsu.autoclicker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

/** Executa os selos pela posição fixa da tela mostrada pelo usuário. */
public class TapAccessibilityService extends AccessibilityService {
    public static volatile TapAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());

    // Posições normalizadas (x,y) dos seis selos na imagem de referência.
    private static final float Z_X=0.815f, Z_Y=0.108f;
    private static final float V_X=0.891f, V_Y=0.108f;
    private static final float X_X=0.815f, X_Y=0.285f;
    private static final float B_X=0.891f, B_Y=0.285f;
    private static final float C_X=0.815f, C_Y=0.455f;
    private static final float N_X=0.891f, N_Y=0.455f;

    @Override public void onServiceConnected() { instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    public boolean tapSequence(String sequence, int width, int height, long gapMs) {
        if (Build.VERSION.SDK_INT < 24 || sequence == null || sequence.isEmpty()) return false;
        if (width <= 0 || height <= 0) return false;
        final long gap = Math.max(6, Math.min(35, gapMs));
        // Até 8 selos por lote deixa espaço para uma chamada de gesto segura.
        dispatchChunk(sequence, 0, width, height, gap);
        return true;
    }

    private void dispatchChunk(final String sequence, final int from, final int width,
                               final int height, final long gap) {
        final int end = Math.min(sequence.length(), from + 8);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        long start = 0;
        for (int i = from; i < end; i++) {
            float[] p = point(sequence.charAt(i), width, height);
            if (p == null) continue;
            Path path = new Path();
            path.moveTo(p[0], p[1]);
            builder.addStroke(new GestureDescription.StrokeDescription(path, start, 7));
            start += gap;
        }
        if (start == 0) { launch(width, height); return; }
        final boolean more = end < sequence.length();
        final long duration = start + 12;
        dispatchGesture(builder.build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                if (more) dispatchChunk(sequence, end, width, height, gap);
                else handler.postDelayed(() -> launch(width, height), Math.min(35, gap));
            }
            @Override public void onCancelled(GestureDescription gestureDescription) {
                // Se o sistema cancelar o lote, não tenta disparar uma enxurrada de toques.
            }
        }, handler);
    }

    private float[] point(char c, int width, int height) {
        switch (c) {
            case 'Z': return new float[]{Z_X*width, Z_Y*height};
            case 'V': return new float[]{V_X*width, V_Y*height};
            case 'X': return new float[]{X_X*width, X_Y*height};
            case 'B': return new float[]{B_X*width, B_Y*height};
            case 'C': return new float[]{C_X*width, C_Y*height};
            case 'N': return new float[]{N_X*width, N_Y*height};
            default: return null;
        }
    }

    /** Toca uma área vazia no centro inferior para lançar o jutsu. */
    private void launch(int width, int height) {
        float x = width * 0.50f;
        float y = height * 0.68f;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(path, 0, 8));
        dispatchGesture(b.build(), null, handler);
    }
}
