package com.jutsu.autoclicker;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.util.DisplayMetrics;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Captura a tela, lê somente a área do Jutsu no topo e executa cada sequência
 * encontrada uma vez. Quando o texto muda ou desaparece, o detector fica pronto
 * para o próximo jutsu.
 */
public class CaptureService extends Service {
    private static final String CHANNEL="jutsu_auto";
    // Área do texto "VBZXZV" da imagem: aproximadamente x=34..67%, y=12..27%.
    private static final float RX1=0.32f, RX2=0.69f, RY1=0.10f, RY2=0.285f;
    private static final Pattern SEAL_PATTERN = Pattern.compile("[VBZXCN]{2,12}");

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private TextRecognizer recognizer;
    private Handler handler;
    private int width,height,gap;
    private boolean busy=false;
    private String lastSequence="";
    private boolean waitingForNew=false;
    private long lastExecution=0;

    @Override public void onCreate(){
        super.onCreate();
        handler=new Handler(Looper.getMainLooper());
        recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        createChannel();
        startForeground(9, notification("Lendo os jutsus no topo da tela"));
        int result=intent.getIntExtra("resultCode",Activity.RESULT_CANCELED);
        Intent data=intent.getParcelableExtra("data");
        gap=intent.getIntExtra("gap",14);
        if(result==Activity.RESULT_OK && data!=null) startCapture(data);
        return START_NOT_STICKY;
    }

    private void startCapture(Intent data){
        MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection=m.getMediaProjection(Activity.RESULT_OK,data);
        DisplayMetrics dm=getResources().getDisplayMetrics();
        width=dm.widthPixels; height=dm.heightPixels;
        reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,2);
        display=projection.createVirtualDisplay("JutsuOCR",width,height,dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
        reader.setOnImageAvailableListener(r -> {
            Image im=null;
            try {
                im=r.acquireLatestImage();
                if(im!=null && !busy) {
                    busy=true;
                    Bitmap b=imageToBitmap(im);
                    im.close();
                    analyze(b);
                } else if(im!=null) im.close();
            } catch(Exception e) {
                if(im!=null) im.close();
                busy=false;
            }
        },handler);
    }

    private Bitmap imageToBitmap(Image image){
        Image.Plane p=image.getPlanes()[0];
        ByteBuffer buf=p.getBuffer();
        int ps=p.getPixelStride(), rs=p.getRowStride();
        int pad=rs-ps*width;
        Bitmap full=Bitmap.createBitmap(width+pad/ps,height,Bitmap.Config.ARGB_8888);
        full.copyPixelsFromBuffer(buf);
        Bitmap out=Bitmap.createBitmap(full,0,0,width,height);
        full.recycle();
        return out;
    }

    private void analyze(Bitmap full){
        int l=(int)(width*RX1), t=(int)(height*RY1);
        int r=(int)(width*RX2), b=(int)(height*RY2);
        if(r<=l||b<=t){ full.recycle(); busy=false; return; }
        Bitmap crop=Bitmap.createBitmap(full,l,t,r-l,b-t);
        full.recycle();
        recognizer.process(InputImage.fromBitmap(crop,0))
                .addOnSuccessListener(text -> {
                    String seq=findSequence(text);
                    if(seq==null) {
                        // O jutsu sumiu: permite novamente até o mesmo código aparecer depois.
                        waitingForNew=false;
                    } else if(!waitingForNew && !seq.equals(lastSequence) &&
                            System.currentTimeMillis()-lastExecution>80) {
                        lastSequence=seq;
                        waitingForNew=true;
                        lastExecution=System.currentTimeMillis();
                        TapAccessibilityService s=TapAccessibilityService.instance;
                        if(s!=null) s.tapSequence(seq,width,height,gap);
                    }
                    busy=false;
                    crop.recycle();
                })
                .addOnFailureListener(e->{ busy=false; crop.recycle(); });
    }

    private String findSequence(Text text){
        String best=null;
        for(Text.TextBlock block:text.getTextBlocks()) {
            for(Text.Line line:block.getLines()) {
                String raw=line.getText().toUpperCase();
                // ML Kit às vezes lê Z/V/X/B/C/N com espaços ou pontuação.
                String s=raw.replaceAll("[^A-Z]","");
                Matcher m=SEAL_PATTERN.matcher(s);
                while(m.find()) {
                    String x=m.group();
                    if(best==null || x.length()>best.length()) best=x;
                }
            }
        }
        return best;
    }

    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CHANNEL,"Jutsu Auto Clicker",NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private Notification notification(String text){
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        return b.setContentTitle("Jutsu Auto Clicker").setContentText(text)
                .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build();
    }

    @Override public void onDestroy(){
        if(handler!=null)handler.removeCallbacksAndMessages(null);
        if(reader!=null)reader.close();
        if(display!=null)display.release();
        if(projection!=null)projection.stop();
        if(recognizer!=null)recognizer.close();
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent){ return null; }
}
