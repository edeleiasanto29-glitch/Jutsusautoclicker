package com.jutsu.autoclicker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;


import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Captura a tela, lê a sequência do jutsu e controla o ciclo automático. */
public class CaptureService extends Service {
    private static final String CHANNEL = "jutsu_auto";
    private static final int NOTIFICATION_ID = 9;

    // Região do texto do jutsu na imagem de referência.
    private static final float RX1=0.32f, RX2=0.69f, RY1=0.10f, RY2=0.285f;
    private static final Pattern SEAL_PATTERN = Pattern.compile("[VBZXCN]{2,12}");

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private TextRecognizer recognizer;
    private Handler handler;
    private WindowManager windowManager;
    private LinearLayout overlayRoot;
    private TextView overlayStatus;
    private TextView overlaySpeed;
    private TextView overlayLaunch;
    private WindowManager.LayoutParams overlayParams;
    private boolean overlayExpanded = false;
    private boolean busy = false;
    private String lastSequence = "";
    private long lastExecution = 0L;
    private int width, height;
    private MediaProjection.Callback projectionCallback;

    @Override public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        createChannel();
        promoteToForeground();

        if (intent == null) return START_NOT_STICKY;
        int result = intent.getIntExtra("resultCode", android.app.Activity.RESULT_CANCELED);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) {
            data = intent.getParcelableExtra("data", Intent.class);
        } else {
            //noinspection deprecation
            data = intent.getParcelableExtra("data");
        }

        if (result == android.app.Activity.RESULT_OK && data != null) {
            safeStartCapture(data);
        } else {
            showStatus("Captura não autorizada");
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void safeStartCapture(Intent data) {
        try {
            // Evita criar uma segunda sessão MediaProjection no mesmo Service.
            stopCaptureOnly();
            MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection=m.getMediaProjection(android.app.Activity.RESULT_OK, data);
            if (projection == null) throw new IllegalStateException("MediaProjection nula");

            projectionCallback = new MediaProjection.Callback() {
                @Override public void onStop() {
                    handler.post(() -> {
                        stopCaptureOnly();
                        showStatus("Captura encerrada pelo sistema");
                    });
                }
            };
            projection.registerCallback(projectionCallback, handler);

            DisplayMetrics dm=getResources().getDisplayMetrics();
            width=Math.max(1, dm.widthPixels);
            height=Math.max(1, dm.heightPixels);
            reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,2);
            display=projection.createVirtualDisplay(
                    "JutsuOCR", width, height, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, handler);

            reader.setOnImageAvailableListener(r -> {
                Image im=null;
                try {
                    im=r.acquireLatestImage();
                    if(im==null) return;
                    if(AppSettings.isPaused(this) || busy) return;
                    busy=true;
                    Bitmap b=imageToBitmap(im);
                    analyze(b);
                } catch(Throwable t) {
                    busy=false;
                    updateNotification("Erro de captura — tentando novamente");
                } finally {
                    if(im!=null) im.close();
                }
            },handler);

            showOverlay();
            showStatus("RODANDO — procurando jutsu");
        } catch (Throwable t) {
            showStatus("Erro ao iniciar captura");
            stopCaptureOnly();
            stopSelf();
        }
    }

    private Bitmap imageToBitmap(Image image) {
        int iw=image.getWidth();
        int ih=image.getHeight();
        if (iw <= 0 || ih <= 0) throw new IllegalStateException("Imagem inválida");
        Image.Plane p=image.getPlanes()[0];
        ByteBuffer buf=p.getBuffer();
        int ps=p.getPixelStride(), rs=p.getRowStride();
        int rowPadding=Math.max(0, rs-ps*iw);
        int paddedWidth=iw + (ps == 0 ? 0 : rowPadding/ps);
        Bitmap full=Bitmap.createBitmap(paddedWidth, ih, Bitmap.Config.ARGB_8888);
        full.copyPixelsFromBuffer(buf);
        Bitmap out=Bitmap.createBitmap(full,0,0,iw,ih);
        full.recycle();
        width=iw; height=ih;
        return out;
    }

    private void analyze(Bitmap full) {
        int l=(int)(width*RX1), t=(int)(height*RY1);
        int r=(int)(width*RX2), b=(int)(height*RY2);
        if(r<=l||b<=t){ full.recycle(); busy=false; return; }
        Bitmap crop;
        try {
            crop=Bitmap.createBitmap(full,l,t,r-l,b-t);
        } catch(Throwable tErr) {
            full.recycle(); busy=false; return;
        }
        full.recycle();

        recognizer.process(InputImage.fromBitmap(crop,0))
                .addOnSuccessListener(text -> {
                    try {
                        String seq=findSequence(text);
                        if (seq == null || seq.length() < 2) {
                            lastSequence = "";
                        } else if (!AppSettings.isPaused(this)
                                && !seq.equals(lastSequence)
                                && System.currentTimeMillis()-lastExecution>120) {
                            lastSequence=seq;
                            lastExecution=System.currentTimeMillis();
                            TapAccessibilityService s=TapAccessibilityService.instance;
                            if(s!=null) {
                                s.tapSequence(seq,width,height,AppSettings.getGap(this));
                                showStatus("Jutsu: " + seq);
                            } else {
                                showStatus("Ative a acessibilidade");
                            }
                        }
                    } finally {
                        crop.recycle();
                        busy=false;
                    }
                })
                .addOnFailureListener(e -> {
                    crop.recycle();
                    busy=false;
                });
    }

    private String findSequence(Text text){
        String best=null;
        for(Text.TextBlock block:text.getTextBlocks()) {
            for(Text.Line line:block.getLines()) {
                String raw=line.getText().toUpperCase(Locale.US);
                String s=raw.replaceAll("[^A-Z]", "");
                s=s.replace('0','O');
                Matcher m=SEAL_PATTERN.matcher(s);
                while(m.find()) {
                    String x=m.group();
                    if(best==null || x.length()>best.length()) best=x;
                }
            }
        }
        return best;
    }

    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CHANNEL,"Jutsu Auto Clicker",NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Controle do leitor automático de jutsus");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private void promoteToForeground() {
        Notification n = notification("Preparando captura de tela");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, n);
        }
    }

    private Notification notification(String text){
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26
                ?new Notification.Builder(this,CHANNEL)
                :new Notification.Builder(this);
        return b.setContentTitle("Jutsu Auto Clicker")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void updateNotification(String text) {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIFICATION_ID, notification(text));
    }

    private void showStatus(String text) {
        updateNotification(text);
        if (overlayStatus != null) {
            handler.post(() -> {
                overlayStatus.setText(AppSettings.isPaused(this) ? "⏸ PAUSADO" : "● " + text);
                updateOverlayValues();
            });
        }
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), Color.argb(55,255,255,255));
        return d;
    }

    private TextView label(String text, float sp) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextColor(Color.WHITE); v.setTextSize(sp);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(8), dp(4), dp(8), dp(4));
        return v;
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(12); b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setMinHeight(dp(36)); b.setMinWidth(dp(44));
        b.setPadding(dp(6), 0, dp(6), 0);
        return b;
    }

    private void showOverlay() {
        if (!SettingsCanDrawOverlays()) return;
        if (overlayRoot != null) return;
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);

        overlayRoot = new LinearLayout(this);
        overlayRoot.setOrientation(LinearLayout.VERTICAL);
        overlayRoot.setPadding(dp(6),dp(6),dp(6),dp(6));
        overlayRoot.setBackground(bg(Color.argb(235,24,25,31), 14));

        Button bubble = smallButton("▶");
        bubble.setBackground(bg(Color.argb(245,80,80,100), 14));
        overlayRoot.addView(bubble, new LinearLayout.LayoutParams(dp(52), dp(48)));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setVisibility(overlayExpanded ? LinearLayout.VISIBLE : LinearLayout.GONE);

        overlayStatus = label("● ATIVO", 13);
        panel.addView(overlayStatus, new LinearLayout.LayoutParams(dp(210), dp(32)));

        LinearLayout gapRow = row("Intervalo");
        overlaySpeed = label("",12);
        Button minus = smallButton("−");
        Button plus = smallButton("+");
        minus.setOnClickListener(v -> { AppSettings.setGap(this, AppSettings.getGap(this)-1); updateOverlayValues(); });
        plus.setOnClickListener(v -> { AppSettings.setGap(this, AppSettings.getGap(this)+1); updateOverlayValues(); });
        gapRow.addView(minus); gapRow.addView(overlaySpeed, new LinearLayout.LayoutParams(0,dp(40),1)); gapRow.addView(plus);
        panel.addView(gapRow);

        LinearLayout launchRow = row("Lançar");
        overlayLaunch = label("",12);
        Button lminus = smallButton("−");
        Button lplus = smallButton("+");
        lminus.setOnClickListener(v -> { AppSettings.setLaunchDelay(this, AppSettings.getLaunchDelay(this)-10); updateOverlayValues(); });
        lplus.setOnClickListener(v -> { AppSettings.setLaunchDelay(this, AppSettings.getLaunchDelay(this)+10); updateOverlayValues(); });
        launchRow.addView(lminus); launchRow.addView(overlayLaunch, new LinearLayout.LayoutParams(0,dp(40),1)); launchRow.addView(lplus);
        panel.addView(launchRow);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button pause = smallButton("Pausar");
        Button stop = smallButton("Parar");
        pause.setOnClickListener(v -> togglePause());
        stop.setOnClickListener(v -> stopSelf());
        actions.addView(pause, new LinearLayout.LayoutParams(0,dp(42),1));
        actions.addView(stop, new LinearLayout.LayoutParams(0,dp(42),1));
        panel.addView(actions);

        Button test = smallButton("Testar Z");
        test.setOnClickListener(v -> {
            if (TapAccessibilityService.instance != null) TapAccessibilityService.instance.tapSingle('Z', width, height);
        });
        panel.addView(test);

        overlayRoot.addView(panel);
        bubble.setOnClickListener(v -> {
            overlayExpanded = !overlayExpanded;
            panel.setVisibility(overlayExpanded ? LinearLayout.VISIBLE : LinearLayout.GONE);
            bubble.setText(overlayExpanded ? "×" : (AppSettings.isPaused(this) ? "▶" : "Ⅱ"));
            updateOverlayValues();
            updateOverlaySize();
        });

        overlayParams = new WindowManager.LayoutParams(
                dp(230), WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.BOTTOM | Gravity.LEFT;
        overlayParams.x = dp(12); overlayParams.y = dp(28);

        try {
            windowManager.addView(overlayRoot, overlayParams);
            updateOverlayValues();
        } catch (Throwable t) {
            overlayRoot = null;
        }
    }

    private LinearLayout row(String title) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        TextView t = label(title, 12);
        r.addView(t, new LinearLayout.LayoutParams(dp(70), dp(40)));
        return r;
    }

    private void updateOverlaySize() {
        if (windowManager != null && overlayRoot != null && overlayParams != null) {
            try { windowManager.updateViewLayout(overlayRoot, overlayParams); } catch (Throwable ignored) { }
        }
    }

    private void updateOverlayValues() {
        if (overlaySpeed != null) overlaySpeed.setText(AppSettings.getGap(this) + " ms");
        if (overlayLaunch != null) overlayLaunch.setText(AppSettings.getLaunchDelay(this) + " ms");
    }

    private void togglePause() {
        boolean paused = !AppSettings.isPaused(this);
        AppSettings.setPaused(this, paused);
        showStatus(paused ? "Pausado" : "Rodando");
        if (!paused) lastSequence = "";
    }

    private boolean SettingsCanDrawOverlays() {
        return Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(this);
    }

    private void removeOverlay() {
        if (windowManager != null && overlayRoot != null) {
            try { windowManager.removeView(overlayRoot); } catch (Throwable ignored) { }
        }
        overlayRoot = null; overlayStatus = null; overlaySpeed = null; overlayLaunch = null;
    }

    private void stopCaptureOnly() {
        if (reader != null) { try { reader.setOnImageAvailableListener(null, null); } catch(Throwable ignored){} try { reader.close(); } catch(Throwable ignored){} reader=null; }
        if (display != null) { try { display.release(); } catch(Throwable ignored){} display=null; }
        if (projection != null) {
            try { if (projectionCallback != null) projection.unregisterCallback(projectionCallback); } catch(Throwable ignored){}
            try { projection.stop(); } catch(Throwable ignored){}
            projection=null;
        }
        busy=false;
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        stopCaptureOnly();
        removeOverlay();
        if (recognizer != null) { try { recognizer.close(); } catch(Throwable ignored){} recognizer=null; }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent){ return null; }
}
