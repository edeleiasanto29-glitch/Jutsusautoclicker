# Jutsu Auto Clicker

Auto-clicker Android para o minigame de selos mostrado pelo usuário.

## O que ele faz
- Captura a tela com MediaProjection.
- Recorta apenas a região superior onde aparece o código do Jutsu.
- Usa ML Kit OCR para ler sequências como `VBZXZV`.
- Mapeia V/B/Z/X/C/N para as posições dos seis selos da tela.
- Executa os toques pela AccessibilityService em sequência, com intervalo configurável.
- Evita repetir o mesmo código enquanto ele permanece visível; espera o código desaparecer ou mudar.

## Coordenadas calibradas pela imagem enviada (1536x691)
- Z: 81.5% x, 10.8% y
- V: 89.1% x, 10.8% y
- X: 81.5% x, 28.5% y
- B: 89.1% x, 28.5% y
- C: 81.5% x, 45.5% y
- N: 89.1% x, 45.5% y

A região OCR é aproximadamente x=34%-67%, y=16%-29% da tela.

## Uso
1. Abra o app.
2. Ative o serviço de acessibilidade para permitir gestos.
3. Permita sobreposição se necessário.
4. Toque em INICIAR AUTO FARM e aceite a captura de tela.
5. Deixe o jogo aberto.

O projeto usa o reconhecimento de texto do ML Kit. A versão unbundled do modelo é pequena, mas pode precisar baixar o modelo no aparelho na primeira utilização.
