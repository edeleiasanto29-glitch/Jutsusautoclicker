# Jutsu Auto Clicker — versão corrigida

Esta versão foi ajustada para Android recente e inclui:

- correção do fluxo de captura MediaProjection;
- callback de encerramento da captura para evitar crashes em Android 14+;
- serviço de Acessibilidade com permissão/declaração compatíveis;
- coordenadas dos seis selos recalibradas para a imagem de referência 1536x691;
- painel flutuante pequeno para pausar/continuar;
- ajuste do intervalo entre selos de 5 a 120 ms;
- ajuste do atraso antes de lançar o jutsu de 20 a 1000 ms;
- botão de teste do selo Z;
- tratamento de erros para a captura não derrubar o app inteiro;
- loop OCR → selos → lançamento → próximo jutsu.

## Uso

1. Abra o app.
2. Ative o serviço em Acessibilidade.
3. Permita "Exibir sobre outros apps".
4. Toque em INICIAR AUTO JUTSU e aceite a captura de tela.
5. O mini painel aparece no canto inferior esquerdo. Toque nele para abrir os controles.

A captura deve ser autorizada novamente a cada nova sessão. O primeiro uso também pode baixar/ativar o modelo de OCR do ML Kit.
